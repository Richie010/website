import pandas as pd
from bs4 import BeautifulSoup
import requests

headers_std = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36',
    'Content-Type': 'text/html',
}

url = "https://www.amazon.in/s?k=stilleto+heels&page=2&qid=1557851935&ref=sr_pg_2"
html = requests.get(url, headers=headers_std).text
soup = BeautifulSoup(html, 'lxml')

print(soup.prettify())  # Print HTML content for inspection

product_name_class = "a-size-base-plus a-color-base a-text-normal"
actual_price_class = "a-price-whole"
rating_class = "a-icon-alt"
no_of_rat_class = 'a-size-base'
main_page_url_class = "a-link-normal"

# Scrape the product details
product_names = [name.text.strip() for name in soup.find_all("span", {"class": product_name_class})]
product_prices = [price.text.strip() for price in soup.find_all("span", {"class": actual_price_class})]
ratings = [rating.text.strip() for rating in soup.find_all("span", {"class": rating_class})]
main_page_urls = ["amazon.in" + url.get('href').strip() for url in soup.find_all("a", {'class': main_page_url_class})]

print("Number of product names:", len(product_names))
print("Number of product prices:", len(product_prices))
print("Number of ratings:", len(ratings))
print("Number of main page URLs:", len(main_page_urls))

print("Sample product name:", product_names[0])
print("Sample product price:", product_prices[0])
print("Sample rating:", ratings[0])

# Ensure all arrays have the same length
min_length = min(len(product_names), len(product_prices), len(ratings), len(main_page_urls))
product_names = product_names[:min_length]
product_prices = product_prices[:min_length]
ratings = ratings[:min_length]
main_page_urls = main_page_urls[:min_length]

# Create DataFrame
df = pd.DataFrame({'product_name': product_names, 'price (INR)': product_prices, 'rating': ratings, 'product_page': main_page_urls})

print(df.head())

df.to_csv('amazon_main_page_scraping.csv', index=False)
