import pandas as pd
from bs4 import BeautifulSoup
import requests

headers_std = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36',
    'Content-Type': 'text/html',
}

url = "https://blog.mirrorreview.com/best-construction-companies-in-california/"
html = requests.get(url, headers=headers_std).text
soup = BeautifulSoup(html, 'html.parser')

# Find all company entries
company_entries = soup.find_all("article", class_="post")

# Lists to store data
company_names = []
establishment_years = []
popular_projects = []

# Loop through each company entry
for entry in company_entries:
    # Extract company name
    company_name_elem = entry.find("h2", class_="entry-title")
    company_name = company_name_elem.text.strip() if company_name_elem else None
    company_names.append(company_name)

    # Extract establishment year
    year_elem = entry.find("span", class_="tr-date")
    establishment_year = year_elem.text.strip() if year_elem else None
    establishment_years.append(establishment_year)

    # Extract popular projects
    projects_elem = entry.find("div", class_="entry-content")
    projects = projects_elem.find_all("li") if projects_elem else None
    popular_projects.append([p.text.strip() for p in projects] if projects else None)

# Create DataFrame
df = pd.DataFrame({
    "Company Name": company_names,
    "Establishment Year": establishment_years,
    "Popular Projects": popular_projects
})

# Display DataFrame
print(df.head())

# Save DataFrame to CSV
df.to_csv('construction_companies_data.csv', index=False)
