function catchPokemon() {
    // Generate a random power for the caught Pokémon (for demo purposes)
    var power = Math.floor(Math.random() * 100) + 1;

    // Send the power to Python backend (using AJAX/fetch)
    fetch('/catch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ power: power })
    })
    .then(response => response.json())
    .then(data => {
        // Update UI with min and max powers
        document.querySelector('.pokemon-list').innerHTML += `<div>${data.minPower} ${data.maxPower}</div>`;
    })
    .catch(error => console.error('Error:', error));
}
