import requests
from bs4 import BeautifulSoup
import csv


def scrape_website(url):
    # Send a GET request to the URL
    response = requests.get(url)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find the section containing the list of construction companies
        companies_section = soup.find('section', id='companies-list')

        if companies_section:
            # Initialize lists to store data
            company_list = []
            establishment_year_list = []
            popular_projects_list = []

            # Find all div elements with class 'single-blog__wrap'
            company_cards = companies_section.find_all('div', class_='single-blog__wrap')

            # Loop through each company card and extract information
            for card in company_cards:
                # Extract company name
                company_name = card.find('h4').text.strip()

                # Extract establishment year (if available)
                establishment_year = card.find('span', class_='establishment-year')
                if establishment_year:
                    establishment_year = establishment_year.text.strip()
                else:
                    establishment_year = "N/A"

                # Extract popular projects (if available)
                projects = card.find('p', class_='popular-projects')
                if projects:
                    popular_projects = projects.text.strip()
                else:
                    popular_projects = "N/A"

                # Append data to lists
                company_list.append(company_name)
                establishment_year_list.append(establishment_year)
                popular_projects_list.append(popular_projects)

            # Return the extracted data
            return company_list, establishment_year_list, popular_projects_list
        else:
            print("Failed to find the section containing the list of construction companies.")
            return None, None, None
    else:
        # If the request was unsuccessful, print an error message
        print("Failed to retrieve data from the website. Status code:", response.status_code)
        return None, None, None


def save_to_csv(data, filename):
    # Unpack the data
    company_list, establishment_year_list, popular_projects_list = data

    # Combine the data into rows
    rows = zip(company_list, establishment_year_list, popular_projects_list)

    # Open a CSV file in write mode
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        # Create a CSV writer object
        writer = csv.writer(csvfile)

        # Write the header row
        writer.writerow(['Company Name', 'Establishment Year', 'Popular Projects'])

        # Write the data rows
        writer.writerows(rows)


# URL of the website to scrape
url = "https://blog.mirrorreview.com/best-construction-companies-in-california/"

# Scrape the website
data = scrape_website(url)

if data:
    # Save the extracted data to a CSV file
    save_to_csv(data, "construction_companies.csv")
    print("Data has been successfully scraped and saved to 'construction_companies.csv'.")
else:
    print("Failed to scrape data from the website.")
